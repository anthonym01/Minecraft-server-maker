#!/bin/bash
java -Xmx4092M -Xms4092M -jar server.jar gui 
